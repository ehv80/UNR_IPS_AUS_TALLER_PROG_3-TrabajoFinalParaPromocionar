package clinica;
// default package
// Generated 08/12/2007 18:01:02 by Hibernate Tools 3.2.0.beta8

import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;

import dbServlets.Hiber8Manager;

/**
 * Home object for domain model class Usuario.
 * @see .Usuario
 * @author Hibernate Tools
 */
public class UsuarioHome {
	
	/**
	 * @author ehv80
	 * Método:	consultaUsuarios
	 * 		Realiza una consulta HQL en la base de datos Clinica, Tabla USUARIOS.
	 * @param	String consultaHQL
	 * @return	List<Usuario>
	 */
	public static List<Usuario> consultaUsuarios(String consultaHQL) throws HibernateException{
//		if (consultaHQL == null ||
//			consultaHQL.equals(""))
//			throw new IllegalArgumentException("La consulta SQL no puede ser nula.");
//
		Session session = null;
		Transaction transaccion = null;
		try {
			session = Hiber8Manager.openHibernateSession();
			transaccion = session.beginTransaction();
			List<Usuario> listaDeUsuarios = (List<Usuario>)(session.createQuery(consultaHQL).list());
			transaccion.commit();
			return listaDeUsuarios;
		} catch (HibernateException ex) {
			if (transaccion != null)
				transaccion.rollback();
			throw ex;
		} finally {
			if (session != null)
				session.close();
		}
	}
	
	/**
	 * @author ehv80 Método: modificaUsuario En caso de modificar usuario con
	 *         éxito retorna Boolean.TRUE En caso contrario retorna
	 *         Boolean.FALSE
	 * @param Usuario
	 *            usuario
	 * @throws HibernateException
	 */
	public static void modificaUsuario(Usuario usuario)
			throws HibernateException {
		Transaction transaccion = null;
		Session session = null;
		try {
			session = Hiber8Manager.openHibernateSession();
			transaccion = session.beginTransaction();
			session.saveOrUpdate(usuario);
			transaccion.commit();
		} catch (HibernateException ex) {
			if (transaccion != null)
				transaccion.rollback();
			throw ex;
		} finally {
			if (session != null)
				session.close();
		}
	}
	
	/**
	 * @author ehv80
	 * Método:	eliminaUsuario
	 * 			En caso de eliminar usuario con éxito retorna Boolean.TRUE
	 * 			En caso contrario retorna Boolean.FALSE
	 * @param Usuario usuario
	 */
	public static void eliminaUsuario(Usuario usuario)
			throws HibernateException {
		Transaction transaccion = null;
		Session session = null;
		try {
			session = Hiber8Manager.openHibernateSession();
			transaccion = session.beginTransaction();
			session.delete(usuario);
			transaccion.commit();
		} catch (HibernateException ex) {
			if (transaccion != null)
				transaccion.rollback();
			throw ex;
		} finally {
			if (session != null)
				session.close();
		}
	}

	/**
	 * Responsable de realizar consultas basada en una instancia ejemplo.
	 * 
	 * @param instance
	 * @return
	 * @throws HibernateException
	 */
	public static List<Usuario> findByExample(Usuario instance) throws HibernateException {
		Transaction transaccion = null;
		Session session = null;
		try {
			session = Hiber8Manager.openHibernateSession();
			transaccion = session.beginTransaction();
			List<Usuario> results = (List<Usuario>) session.createCriteria(Usuario.class).add(
					Example.create(instance)).list();
			transaccion.commit();
			return results;
		} catch (HibernateException ex) {
			//catcheada y relanzada para hacer el rollback
			if (transaccion != null)
				transaccion.rollback();
			throw ex;
		} finally {
			if (session != null)
				session.close();
		}
	}
}
