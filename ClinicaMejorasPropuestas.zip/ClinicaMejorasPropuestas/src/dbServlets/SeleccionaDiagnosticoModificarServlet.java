package dbServlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;

import clinica.Diagnostico;
import clinica.DiagnosticoHome;

/**
 * Servlet implementation class for Servlet: SeleccionaDiagnosticoModificarServlet
 *
 */
 public class SeleccionaDiagnosticoModificarServlet extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet 
 {
	 
	 private static String mensaje;
	 
	 public static void setMensaje(String mensaje){ SeleccionaDiagnosticoModificarServlet.mensaje = mensaje; }
	 
	 public static String getMensaje(){ return SeleccionaDiagnosticoModificarServlet.mensaje; }
	 
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public SeleccionaDiagnosticoModificarServlet() {
		super();
	}   	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String selectorDiagnosticoModificar;
		Diagnostico diagnosticoModificar;
		String consultaHQL;
		List<Diagnostico> listaDeDiagnosticos;
		
		try
		{
			if( request.getParameter("selectorDiagnosticoModificar") != null && !request.getParameter("selectorDiagnosticoModificar").equals(""))
			{
				selectorDiagnosticoModificar = request.getParameter("selectorDiagnosticoModificar");
				
				//lo pongo en la HttpSession para tenerlo
				request.getSession().setAttribute("idDiagnosticoModificar", selectorDiagnosticoModificar);
				
				consultaHQL = "select d from Diagnostico as d where 1=1 and d.idDiagnostico = '" + selectorDiagnosticoModificar + "'";
				//1º Obtiene el Diagnóstico desde la Base de Datos
				listaDeDiagnosticos = DiagnosticoHome.consultaDiagnosticos(consultaHQL);
				if(listaDeDiagnosticos == null)
				{
					if( DiagnosticoHome.getMensaje() != null && !DiagnosticoHome.getMensaje().equals("") )
					{
						SeleccionaDiagnosticoModificarServlet.setMensaje( DiagnosticoHome.getMensaje() );
						request.getSession().setAttribute("mensajeSeleccionaDiagnosticoModificar", 
								SeleccionaDiagnosticoModificarServlet.getMensaje() );
						response.sendRedirect("do_modifica_diagnostico.jsp");
					}
					else
					{
						SeleccionaDiagnosticoModificarServlet.setMensaje("Error en DiagnosticoHome.consultaDiagnosticos(consulatHQL) ..!");
						request.getSession().setAttribute("mensajeSeleccionaDiagnosticoModificar", 
								SeleccionaDiagnosticoModificarServlet.getMensaje() );
						response.sendRedirect("do_modifica_diagnostico.jsp");
					}
				}
				else if( listaDeDiagnosticos != null )
				{
					if( listaDeDiagnosticos.isEmpty() )
					{
						SeleccionaDiagnosticoModificarServlet.setMensaje("El Diagnóstico seleccionado ya no está almacenado en la Base de Datos ..!");
						request.getSession().setAttribute("mensajeSeleccionaDiagnosticoModificar", 
								SeleccionaDiagnosticoModificarServlet.getMensaje() );
						response.sendRedirect("do_modifica_diagnostico.jsp");
					}
					else if( !listaDeDiagnosticos.isEmpty() )
					{
						if( listaDeDiagnosticos.size() == 1 )
						{
							if( String.valueOf( listaDeDiagnosticos.get(0).getIdDiagnostico() ).equals(selectorDiagnosticoModificar) )
							{
								diagnosticoModificar = listaDeDiagnosticos.get(0); //índice comienza en cero!

								request.getSession().setAttribute("diagnosticoModificar", diagnosticoModificar);

								//todavía no pone en null el Paciente seleccionado
								response.sendRedirect("do_modifica_diagnostico.jsp");
							}
						}
						else
						{
							SeleccionaDiagnosticoModificarServlet.setMensaje("Error en la consulta HQL al buscar Diagnóstico ..!");
							request.getSession().setAttribute("mensajeSeleccionaDiagnosticoModificar", 
									SeleccionaDiagnosticoModificarServlet.getMensaje() );
							response.sendRedirect("do_modifica_diagnostico.jsp");
						}
					}
				}
			}
			else
			{
				SeleccionaDiagnosticoModificarServlet.setMensaje("Debe elegir un Diagnóstico en el selector ..!");
				request.getSession().setAttribute("mensajeSeleccionaDiagnosticoModificar", SeleccionaDiagnosticoModificarServlet.getMensaje() );
				response.sendRedirect("do_modifica_diagnostico.jsp");
			}
		}
		catch(HibernateException hex)
		{
			SeleccionaDiagnosticoModificarServlet.setMensaje(
					"Ha ocurrido una Excepción en SeleccionaDiagnosticoModificarServlet.doPost( request, response ) " + hex);
			request.getSession().setAttribute("mensajeSeleccionaDiagnosticoModificar", SeleccionaDiagnosticoModificarServlet.getMensaje() );
			response.sendRedirect("do_modifica_diagnostico.jsp");
		}
		catch(Exception ex)
		{
			SeleccionaDiagnosticoModificarServlet.setMensaje(
					"Ha ocurrido una Excepción en SeleccionaDiagnosticoModificarServlet.doPost( request, response ) " + ex);
			request.getSession().setAttribute("mensajeSeleccionaDiagnosticoModificar", SeleccionaDiagnosticoModificarServlet.getMensaje() );
			response.sendRedirect("do_modifica_diagnostico.jsp");
		}
	}   	  	    
}