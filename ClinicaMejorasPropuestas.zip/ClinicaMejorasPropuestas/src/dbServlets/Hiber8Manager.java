package dbServlets;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Hiber8Manager {

	private static SessionFactory hibernateSessionFactory;

	/**
	 * Inicializa el único SessionFactory para toda la aplicación.
	 * 
	 * @param void
	 * @return SessionFactory
	 */
	private static SessionFactory getHibernateSessionFactory()
			throws HibernateException {
		if (Hiber8Manager.hibernateSessionFactory == null)
			Hiber8Manager.hibernateSessionFactory = new Configuration().configure()
					.buildSessionFactory();
		return Hiber8Manager.hibernateSessionFactory;
	}

	/**
	 * Inicializa estáticamente la Session.
	 * 
	 * @param void
	 * @return 
	 */
	public static Session openHibernateSession() throws HibernateException {
		return getHibernateSessionFactory().openSession();
	}

	/**
	 * Cierra estáticamente la Session.
	 * 
	 * @param void
	 * @return void
	 */
	public static void closeHibernateSession(Session hibernateSession) throws HibernateException {
		hibernateSession.close();
	}


}
