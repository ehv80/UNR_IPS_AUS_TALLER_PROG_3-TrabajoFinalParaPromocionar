package dbServlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;

import clinica.Paciente;
import clinica.PacienteHome;

/**
 * Servlet implementation class for Servlet: EliminaPacienteServlet
 *
 */
 public class EliminaPacienteServlet extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet 
 {
	 private static String mensaje;
	 
	 public static void setMensaje(String mensaje){ EliminaPacienteServlet.mensaje = mensaje; }
	 
	 public static String getMensaje(){ return EliminaPacienteServlet.mensaje; }
	 
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public EliminaPacienteServlet() 
	{
		super();
	}   	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String eleccionEliminarPaciente;
		Paciente pacienteEliminar;
		Boolean isSuccesfullDeleted = Boolean.FALSE; //por defecto
		
		try
		{
			if( request.getParameter("eleccionEliminarPaciente") != null && !request.getParameter("eleccionEliminarPaciente").equals("") )
			{
				eleccionEliminarPaciente = request.getParameter("eleccionEliminarPaciente");
				request.getSession().setAttribute("eleccionEliminarPaciente", eleccionEliminarPaciente );
				
				if( eleccionEliminarPaciente.equals("SI") )
				{
					pacienteEliminar = (Paciente)request.getSession().getAttribute("pacienteEliminar");
					if( pacienteEliminar == null )
					{
						EliminaPacienteServlet.setMensaje(" El Paciente que desea eliminar no puede ser nulo ..! Intente nuevamente ..!");
						request.getSession().setAttribute("mensaje", EliminaPacienteServlet.getMensaje() );
						response.sendRedirect("do_elimina_paciente.jsp");
					}
					else if( pacienteEliminar != null )
					{
						isSuccesfullDeleted = PacienteHome.eliminaPaciente(pacienteEliminar);
						
						if( isSuccesfullDeleted.booleanValue() == true )
						{
							request.getSession().setAttribute("pacienteEliminar", null); // importante
							
							EliminaPacienteServlet.setMensaje(" El Paciente ha sido eliminado satisfactoriamente ..!");
							request.getSession().setAttribute("mensaje", EliminaPacienteServlet.getMensaje() );
							response.sendRedirect("do_elimina_paciente.jsp");
						}
						else if( isSuccesfullDeleted.booleanValue() == false )
						{
							EliminaPacienteServlet.setMensaje(" El Paciente NO SE PUEDE ELIMINAR de la Base de Datos PORQUE POSEE Diagnósticos REGISTRADOS. Debe eliminar primero sus Diagnósticos ..!");
							request.getSession().setAttribute("mensaje", EliminaPacienteServlet.getMensaje() );
							response.sendRedirect("do_elimina_paciente.jsp");
						}
					}
				}
				else if( eleccionEliminarPaciente.equals("NO") )
				{
					EliminaPacienteServlet.setMensaje(" Usted ha elegido no eliminar el Paciente ..!");
					request.getSession().setAttribute("mensaje", EliminaPacienteServlet.getMensaje() );
					response.sendRedirect("do_elimina_paciente.jsp");
				}
				else
				{
					EliminaPacienteServlet.setMensaje(" Debe elegir por \"SI\" o por \"NO\" ..!");
					request.getSession().setAttribute("mensaje", EliminaPacienteServlet.getMensaje() );
					response.sendRedirect("do_elimina_paciente.jsp");
				}
			}
			else
			{
				EliminaPacienteServlet.setMensaje(" Debe elegir por \"SI\" o por \"NO\" ..!");
				request.getSession().setAttribute("mensaje", EliminaPacienteServlet.getMensaje() );
				response.sendRedirect("do_elimina_paciente.jsp");
			}
		}
		catch(HibernateException hex)
		{
			EliminaPacienteServlet.setMensaje("Ha ocurrido una Excepción en EliminaPacienteServlet.doPost(request, response) : " + hex);
			request.getSession().setAttribute("mensaje", EliminaPacienteServlet.getMensaje() );
			response.sendRedirect("do_elimina_paciente.jsp");			
		}
		catch(Exception ex)
		{
			EliminaPacienteServlet.setMensaje("Ha ocurrido una Excepción en EliminaPacienteServlet.doPost(request, response) : " + ex);
			request.getSession().setAttribute("mensaje", EliminaPacienteServlet.getMensaje() );
			response.sendRedirect("do_elimina_paciente.jsp");			
		}
	}   	  	    
}