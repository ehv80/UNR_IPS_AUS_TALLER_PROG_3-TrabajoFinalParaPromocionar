package dbServlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;

import clinica.Paciente;
import clinica.PacienteHome;

/**
 * Servlet implementation class for Servlet: SeleccionaPacienteModificarServlet
 *
 */
 public class SeleccionaPacienteModificarServlet extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet 
 {
	 private static String mensaje;
	 
	 public static void setMensaje( String mensaje ){ SeleccionaPacienteModificarServlet.mensaje = mensaje; }
	 
	 public static String getMensaje() { return SeleccionaPacienteModificarServlet.mensaje; }
	 
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public SeleccionaPacienteModificarServlet() 
	{
		super();
	}   	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String selectorPacienteModificar;
		String consultaHQL;
		List<Paciente> listaDePacientes;
		Paciente pacienteSeleccionado;
		try
		{
			if( request.getParameter("selectorPacienteModificar") != null && 
					!request.getParameter("selectorPacienteModificar").equals("") 
				)
			{
				selectorPacienteModificar = request.getParameter("selectorPacienteModificar");
				consultaHQL = "select p from Paciente as p where 1=1 and p.idPaciente = '" + selectorPacienteModificar + "'";
				listaDePacientes = PacienteHome.consultaPacientes(consultaHQL);
				if( listaDePacientes == null )
				{
					if( PacienteHome.getMensaje() == null )
					{
						SeleccionaPacienteModificarServlet.setMensaje( "EL Paciente seleccionado no puede ser nulo ..! Vuelva a intentarlo ..!" );
						request.getSession().setAttribute("mensajeSeleccionaPacienteModificar" , SeleccionaPacienteModificarServlet.getMensaje() );
						response.sendRedirect("do_modifica_paciente.jsp");
					}
					else if( PacienteHome.getMensaje() != null && !PacienteHome.getMensaje().equals("") )
					{
						SeleccionaPacienteModificarServlet.setMensaje( PacienteHome.getMensaje() );
						request.getSession().setAttribute("mensajeSeleccionaPacienteModificar" , SeleccionaPacienteModificarServlet.getMensaje() );
						response.sendRedirect("do_modifica_paciente.jsp");
					}
				}
				else if( listaDePacientes != null )
				{
					if( listaDePacientes.isEmpty() )
					{
						SeleccionaPacienteModificarServlet.setMensaje( "EL Paciente que ha seleccionado para modificar no está registrado en la Base de Datos ..! Vuelva a intentarlo ..!" );
						request.getSession().setAttribute("mensajeSeleccionaPacienteModificar" , SeleccionaPacienteModificarServlet.getMensaje() );
						response.sendRedirect("do_modifica_paciente.jsp");
					}
					else if( !listaDePacientes.isEmpty() )
					{
						if( listaDePacientes.size() == 1 )
						{
							pacienteSeleccionado = listaDePacientes.get(0); //índice comienza en cero
							if( String.valueOf( pacienteSeleccionado.getIdPaciente() ).equals( selectorPacienteModificar ) )
							{
								request.getSession().setAttribute("pacienteSeleccionado", pacienteSeleccionado);
								response.sendRedirect("do_modifica_paciente.jsp");
							}
						}
						else
						{
							SeleccionaPacienteModificarServlet.setMensaje( "EL Paciente que ha seleccionado para modificar no está registrado en la Base de Datos ..! Vuelva a intentarlo ..!" );
							request.getSession().setAttribute("mensajeSeleccionaPacienteModificar" , SeleccionaPacienteModificarServlet.getMensaje() );
							response.sendRedirect("do_modifica_paciente.jsp");
						}
					}
				}
			}	
			else
			{
				SeleccionaPacienteModificarServlet.setMensaje("Debe seleccionar uno de los Pacientes en el selector ..!");
				request.getSession().setAttribute("mensajeSeleccionaPacienteModificar", SeleccionaPacienteModificarServlet.getMensaje() );
				response.sendRedirect("do_modifica_paciente.jsp");
			}
		}
		catch(HibernateException hex)
		{
			SeleccionaPacienteModificarServlet.setMensaje("Ha ocurrido una Excepción en SeleccionaPacienteModificarServlet.doPost(request, response) : " + hex);
			request.getSession().setAttribute("mensajeSeleccionaPacienteModificar", SeleccionaPacienteModificarServlet.getMensaje() );
			response.sendRedirect("do_modifica_paciente.jsp");
		}
		catch(Exception ex)
		{
			SeleccionaPacienteModificarServlet.setMensaje("Ha ocurrido una Excepción en SeleccionaPacienteModificarServlet.doPost(request, response) : " + ex);
			request.getSession().setAttribute("mensajeSeleccionaPacienteModificar", SeleccionaPacienteModificarServlet.getMensaje() );
			response.sendRedirect("do_modifica_paciente.jsp");
		}	
	}	  	    
}