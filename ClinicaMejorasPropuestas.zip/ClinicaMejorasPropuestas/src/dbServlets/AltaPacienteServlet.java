package dbServlets;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;

import clinica.Paciente;
import clinica.PacienteHome;

import utility.FechaUtil;

/**
 * Servlet implementation class for Servlet: AltaPacienteServlet
 *
 */
 public class AltaPacienteServlet extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet 
 {
	 private static String mensaje;
	 
	 public static void setMensaje( String mensaje ){ AltaPacienteServlet.mensaje = mensaje; }
	 
	 public static String getMensaje(){ return AltaPacienteServlet.mensaje; }
	 
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public AltaPacienteServlet() {
		super();
	}   	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		//No pueden haber Pacientes con igual "Id de Paciente" => controlado por la Base de Datos e Hibernate "increment"
		//"     "     "       "      "    "   "Tipo de Documento" y "Número de Documento" => hay que Controlar
		//Pueden haber Pacientes que tengan mismo "Nombre" , "Apellido", "Fecha de Nacimiento", "Obra Social", "Sexo" , "Estado de Vida"
		
		//int idPacienteAlta;
		String nombrePacienteAlta;
		String apellidoPacienteAlta;
		Date fechaNacimientoPacienteAlta;
			String fechaNacimientoPacienteAltaTemp;
			String anioNacimientoPacienteAlta;
			String mesNacimientoPacienteAlta;
			String diaNacimientoPacienteAlta;
		String tipoDeDocumentoPacienteAlta;
		int numeroDeDocumentoPacienteAlta;
		String obraSocialPacienteAlta;
		String sexoPacienteAlta;
		boolean estaVivoPacienteAlta;
		
		String consultaHQL = ""; //por defecto
		Paciente paciente;
		List<Paciente> listaDePacientes;
		Boolean isTipoYNroDeDocumentoRepeated = Boolean.FALSE; //por defecto
		Boolean isPacienteSuccesfullSaved = Boolean.FALSE; //por defecto
		try
		{
			
			if( request.getParameter("nombrePacienteAlta") != null && !request.getParameter("nombrePacienteAlta").equals("") && 
				request.getParameter("apellidoPacienteAlta") != null &&	!request.getParameter("apellidoPacienteAlta").equals("") &&
				request.getParameter("anioNacimientoPacienteAlta") != null && !request.getParameter("anioNacimientoPacienteAlta").equals("") &&
				request.getParameter("mesNacimientoPacienteAlta") != null && !request.getParameter("mesNacimientoPacienteAlta").equals("") &&
				request.getParameter("diaNacimientoPacienteAlta") != null && !request.getParameter("diaNacimientoPacienteAlta").equals("") &&
				request.getParameter("tipoDeDocumentoPacienteAlta") != null && !request.getParameter("tipoDeDocumentoPacienteAlta").equals("") &&
				request.getParameter("numeroDeDocumentoPacienteAlta") != null && !request.getParameter("numeroDeDocumentoPacienteAlta").equals("") &&
				request.getParameter("obraSocialPacienteAlta") != null && !request.getParameter("obraSocialPacienteAlta").equals("") &&
				request.getParameter("sexoPacienteAlta") != null && !request.getParameter("sexoPacienteAlta").equals("") &&
				request.getParameter("estaVivoPacienteAlta") != null && !request.getParameter("estaVivoPacienteAlta").equals("")
			)
			{
				nombrePacienteAlta 		= request.getParameter("nombrePacienteAlta");
				apellidoPacienteAlta 	= request.getParameter("apellidoPacienteAlta");
				anioNacimientoPacienteAlta = request.getParameter("anioNacimientoPacienteAlta");
				mesNacimientoPacienteAlta = request.getParameter("mesNacimientoPacienteAlta");
				diaNacimientoPacienteAlta = request.getParameter("diaNacimientoPacienteAlta");
				tipoDeDocumentoPacienteAlta = request.getParameter("tipoDeDocumentoPacienteAlta");
				numeroDeDocumentoPacienteAlta = Integer.parseInt( request.getParameter("numeroDeDocumentoPacienteAlta") );
				obraSocialPacienteAlta = request.getParameter("obraSocialPacienteAlta");
				sexoPacienteAlta = request.getParameter("sexoPacienteAlta");
				estaVivoPacienteAlta = Boolean.parseBoolean( request.getParameter("estaVivoPacienteAlta") );
				
				request.getSession().setAttribute("nombrePacienteAlta", nombrePacienteAlta);
				request.getSession().setAttribute("apellidoPacienteAlta", apellidoPacienteAlta);
				request.getSession().setAttribute("anioNacimientoPacienteAlta", anioNacimientoPacienteAlta);
				request.getSession().setAttribute("mesNacimientoPacienteAlta", mesNacimientoPacienteAlta);
				request.getSession().setAttribute("diaNacimientoPacienteAlta", diaNacimientoPacienteAlta);
				request.getSession().setAttribute("tipoDeDocumentoPacienteAlta", tipoDeDocumentoPacienteAlta);
				request.getSession().setAttribute("numeroDeDocumentoPacienteAlta", String.valueOf( numeroDeDocumentoPacienteAlta ) );
				request.getSession().setAttribute("obraSocialPacienteAlta", obraSocialPacienteAlta);
				request.getSession().setAttribute("sexoPacienteAlta", sexoPacienteAlta);
				request.getSession().setAttribute("estaVivoPacienteAlta", String.valueOf( estaVivoPacienteAlta ) );
				
				//Controlar si la fecha es válida
				//	Enero		tiene	31 días
				//	Febrero		tiene	28 días si año no es Bisiesto
				//	Febrero		tiene	29 días si año es Bisiesto
				//	Marzo		tiene	31 días
				//	Abril		tiene	30 días
				//	Mayo		tiene	31 días
				//	Junio		tiene	30 días
				//	Julio		tiene	31 días
				//	Agosto		tiene	31 días
				//	Septiembre	tiene	30 días
				//	Octubre		tiene	31 días
				// 	Noviembre	tiene	30 días
				//	Diciembre	tiene	31 días
				// Mediante FechaUtil.validaFecha(cadenaFecha) 
				
				fechaNacimientoPacienteAltaTemp = anioNacimientoPacienteAlta + "-" + mesNacimientoPacienteAlta + "-" + diaNacimientoPacienteAlta;
				
				fechaNacimientoPacienteAlta = FechaUtil.validaFecha(fechaNacimientoPacienteAltaTemp);
				
				if( fechaNacimientoPacienteAlta != null )
				{
					//Caso fecha correcta
					//Falta verificar si el "Tipo de Documento" y el "Número de Documento" ya está registrado en otro Paciente
				
					consultaHQL = " select p from Paciente as p where 1=1 and p.tpoDoc = '" + tipoDeDocumentoPacienteAlta + "'" +
						" and p.nroDoc = '" + String.valueOf( numeroDeDocumentoPacienteAlta ) + "'";
					
					listaDePacientes = PacienteHome.consultaPacientes(consultaHQL);
					
					if( listaDePacientes != null )
					{
						if( listaDePacientes.isEmpty() )
						{
							//No hay Paciente registrado que tenga ese Tipo y Número de Documento => puede guardarlo
							//Crea un nuevo Paciente
							paciente = new Paciente(
									nombrePacienteAlta, 
									apellidoPacienteAlta, 
									fechaNacimientoPacienteAlta, 
									tipoDeDocumentoPacienteAlta, 
									numeroDeDocumentoPacienteAlta , 
									obraSocialPacienteAlta, 
									sexoPacienteAlta, 
									estaVivoPacienteAlta
								);
							isPacienteSuccesfullSaved = PacienteHome.almacenaPaciente(paciente);
							if( isPacienteSuccesfullSaved.booleanValue() == true )
							{
								//Avisa que fue guardado el Paciente y redirecciona a do_alta_paciente.jsp
								AltaPacienteServlet.setMensaje("El Paciente ha sido guardado satisfactoriamente en la Base de Datos ..! ");
								request.getSession().setAttribute("mensaje", AltaPacienteServlet.getMensaje() );
								//request.getSession().setAttribute("isTipoYNroDeDocumentoRepeated" , isTipoYNroDeDocumentoRepeated );
								response.sendRedirect("do_alta_paciente.jsp");
							}
							if( isPacienteSuccesfullSaved.booleanValue() == false )
							{
								//Avisa que el Paciente no se pudo guardar y redirecciona a do_alta_paciente.jsp
								AltaPacienteServlet.setMensaje("El Paciente no ha sido guardado en la Base de Datos, intente nuevamente ..! ");
								request.getSession().setAttribute("mensaje", AltaPacienteServlet.getMensaje() );
								//request.getSession().setAttribute("isTipoYNroDeDocumentoRepeated" , isTipoYNroDeDocumentoRepeated );
								response.sendRedirect("do_alta_paciente.jsp");
							}
						}
						if( !listaDePacientes.isEmpty() )
						{
							//Hay otro Paciente que tiene ese Tipo y Número de Documento
							AltaPacienteServlet.setMensaje("El Paciente no ha sido guardado en la Base de Datos porque ya existe un " +
									" Paciente registrado con ese Tipo y Número de Documento ..! ");
							request.getSession().setAttribute("mensaje", AltaPacienteServlet.getMensaje() );
							
							isTipoYNroDeDocumentoRepeated = Boolean.TRUE;
							
							//request.getSession().setAttribute("isTipoYNroDeDocumentoRepeated" , isTipoYNroDeDocumentoRepeated );
							response.sendRedirect("do_alta_paciente.jsp");
						}
					}
					else
					{
						if( PacienteHome.getMensaje() != null && !PacienteHome.getMensaje().equals("") )
						{
							AltaPacienteServlet.setMensaje( PacienteHome.getMensaje() );
							request.getSession().setAttribute("mensaje", AltaPacienteServlet.getMensaje() );
							//request.getSession().setAttribute("isTipoYNroDeDocumentoRepeated" , isTipoYNroDeDocumentoRepeated );
							response.sendRedirect("do_alta_paciente.jsp");
						}
						else
						{
							AltaPacienteServlet.setMensaje("Ha ocurrido un error en PacienteHome.consultaPacientes(consultaHQL) " + 
									" la lista de Pacientes consultados no puede ser nula ..!");
							request.getSession().setAttribute("mensaje", AltaPacienteServlet.getMensaje() );
							//request.getSession().setAttribute("isTipoYNroDeDocumentoRepeated" , isTipoYNroDeDocumentoRepeated );
							response.sendRedirect("do_alta_paciente.jsp");
						}
					}
					
				}
				else
				{
					if( FechaUtil.getMensaje() != null && !FechaUtil.getMensaje().equals("") )
					{
						AltaPacienteServlet.setMensaje( FechaUtil.getMensaje() );
						request.getSession().setAttribute("mensaje", AltaPacienteServlet.getMensaje() );
						//request.getSession().setAttribute("isTipoYNroDeDocumentoRepeated" , isTipoYNroDeDocumentoRepeated );
						response.sendRedirect("do_alta_paciente.jsp");
					}
					else
					{
						AltaPacienteServlet.setMensaje("Debe seleccionar una Fecha válida ..!");
						request.getSession().setAttribute("mensaje", AltaPacienteServlet.getMensaje() );
						//request.getSession().setAttribute("isTipoYNroDeDocumentoRepeated" , isTipoYNroDeDocumentoRepeated );
						response.sendRedirect("do_alta_paciente.jsp");
					}
				}
			}
			else
			{
				AltaPacienteServlet.setMensaje("Debe completar todos los campos del formulario ..! ");
				request.getSession().setAttribute("mensaje", AltaPacienteServlet.getMensaje() );
				//request.getSession().setAttribute("isTipoYNroDeDocumentoRepeated" , isTipoYNroDeDocumentoRepeated );
				response.sendRedirect("do_alta_paciente.jsp");
			}
		}
		catch(HibernateException hex)
		{
			AltaPacienteServlet.setMensaje("Ha ocurrido una Excepción en AltaPacienteServlet.doPost( request, response ) : " + hex);
			request.getSession().setAttribute("mensaje", AltaPacienteServlet.getMensaje() );
			//request.getSession().setAttribute("isTipoYNroDeDocumentoRepeated" , isTipoYNroDeDocumentoRepeated );
			response.sendRedirect("do_alta_paciente.jsp");
		}
		catch(Exception ex)
		{
			AltaPacienteServlet.setMensaje("Ha ocurrido una Excepción en AltaPacienteServlet.doPost( request, response ) : " + ex);
			request.getSession().setAttribute("mensaje", AltaPacienteServlet.getMensaje() );
			//request.getSession().setAttribute("isTipoYNroDeDocumentoRepeated" , isTipoYNroDeDocumentoRepeated );
			response.sendRedirect("do_alta_paciente.jsp");			
		}
	}   	  	    
}