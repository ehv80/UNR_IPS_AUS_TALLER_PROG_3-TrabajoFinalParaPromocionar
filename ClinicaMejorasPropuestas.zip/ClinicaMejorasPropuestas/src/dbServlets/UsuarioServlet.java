package dbServlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;

import utility.FieldValueError;
import utility.UserNotification;
import utility.UserNotification.Level;
import clinica.Usuario;
import clinica.UsuarioHome;
import clinica.ValidationException;

/**
 * Servlet implementation class for Servlet: UsuarioServlet
 *
 */
public class UsuarioServlet extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {

	public static final String PARAM_PASSWORD = "password";
	public static final String PARAM_USERNAME = "username";
	public static final String PARAM_APELLIDO = "apellido";
	public static final String PARAM_NOMBRE_REAL = "nombreReal";

	public static final String LISTA_USUARIOS = "lista_usuarios";

	public static final String ACCION_BORRAR = "borrar";
	public static final String ACCION_ACTUALIZAR = "actualizar";
	public static final String ACCION_LISTAR = "listar";
	public static final Object ACCION_REGISTRAR = "registrar";

	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}  	
	
	/*
	 * (non-Java-doc)
	 * 
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request,
	 *      HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		String accion = request.getParameter("accion");
		if (accion == null)
			accion = ACCION_LISTAR;

		// validar que el usuario está autenticado
		Usuario usuario = LoginServlet.getUsuarioEnSesion(request);
		if (!ACCION_REGISTRAR.equals(accion) && usuario == null) {
			UserNotification
					.addMessage(
							request,
							"Está intentando acceder a un recurso para el cual necesita estar autenticado, por favor registrese o logueese.",
							Level.ERROR);
			request.getRequestDispatcher("index.jsp")
					.forward(request, response);
			return;
		}

		//
		// el procesamiento se realiza según el valor del parámetro "accion"
		// 
		if (ACCION_LISTAR.equals(accion)) {
			doListar(request, response);
		} else if (ACCION_ACTUALIZAR.equals(accion)) {
			doActualizar(request, response);
		} else if (ACCION_BORRAR.equals(accion)) {
			doEliminar(request, response);
		} else if (ACCION_REGISTRAR.equals(accion)) {
			doRegistrar(request, response);
		}
	}

	/**
	 * Responsable de llevar adelante la registración de un usuario del sistema.
	 * 
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	private void doRegistrar(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		try {
			String nombreReal = request.getParameter(PARAM_NOMBRE_REAL);
			String apellido = request.getParameter(PARAM_APELLIDO);
			String nombreAcceso = request.getParameter(PARAM_USERNAME);
			String claveAcceso = request.getParameter(PARAM_PASSWORD);

			boolean validos = paramsValidos(nombreReal, apellido, nombreAcceso,
					claveAcceso, request);

			Usuario usuario = new Usuario(null, null, nombreAcceso, null);
			// validar que el username no esté repetido
			List<Usuario> match = UsuarioHome.findByExample(usuario);
			if (!match.isEmpty()) {
				validos = false;
				FieldValueError
						.setFieldError(
								PARAM_USERNAME,
								"El nombre de acceso ya está en uso, por favor seleccione uno que no esté en uso.",
								request);
			}

			if (validos) {
				usuario.setNombreReal(nombreReal);
				usuario.setApellido(apellido);
				usuario.setNombreAcceso(nombreAcceso);
				usuario.setClaveAcceso(claveAcceso);
				UsuarioHome.modificaUsuario(usuario);
				UserNotification
						.addMessage(request,
								"Ha sido registrado satisfactoriamente ..!",
								Level.INFO);
				UserNotification
						.addMessage(
								request,
								"Ahora puede obtener acceso a los recursos del Portal autenticándose mediante el enlace llamado \"Login\" ..!",
								Level.INFO);
			} else {
				request.getRequestDispatcher("do_registra_usuario.jsp")
						.forward(request, response);
				return;
			}
		} catch (HibernateException e) {
			UserNotification
					.addMessage(
							request,
							"Ha ocurrido un error al acceder a la base de datos. Por favor comuníquelo al administrador del sitio.",
							Level.ERROR);
		}
		request.getRequestDispatcher("index.jsp").forward(request, response);
	}

	/**
	 * Responsable de borrar los datos del usuario.
	 * 
	 * @param request
	 * @param response
	 * @throws IOException
	 * @throws ServletException
	 */
	private void doEliminar(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String eleccionEliminaUsuario = request
				.getParameter("eleccionEliminaUsuario");
		if (eleccionEliminaUsuario != null
				&& eleccionEliminaUsuario.equals("SI")) {

			try {
				Usuario usuario = LoginServlet.getUsuarioEnSesion(request);
				UsuarioHome.eliminaUsuario(usuario);
				UserNotification
						.addMessage(
								request,
								"Sus datos han sido borrados satisfactoriamente del sistema.",
								Level.INFO);
				request.getSession().invalidate();
			} catch (HibernateException e) {
				UserNotification
						.addMessage(
								request,
								"Ha ocurrido un error al acceder a la base de datos. Por favor comuníquelo al administrador del sitio.",
								Level.ERROR);
			}
		} else {
			UserNotification
					.addMessage(
							request,
							"Sus datos NO han sido borrados, puede continuar utilizando el sitio normalmente.",
							Level.INFO);
		}
		request.getRequestDispatcher("index.jsp").forward(request, response);
	}

	/**
	 * Responsable de actualizar los datos de usuario.
	 * 
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	private void doActualizar(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		try {
			String nombreReal = request.getParameter(PARAM_NOMBRE_REAL);
			String apellido = request.getParameter(PARAM_APELLIDO);
			String nombreAcceso = request.getParameter(PARAM_USERNAME);
			String claveAcceso = request.getParameter(PARAM_PASSWORD);
			
			boolean validos = paramsValidos(nombreReal, apellido, nombreAcceso, claveAcceso, request);

			Usuario usuario = LoginServlet.getUsuarioEnSesion(request);
			if (!usuario.getNombreAcceso().equals(nombreAcceso)) {
				Usuario sample = new Usuario(null, null, nombreAcceso,
						null);
				// validar que el username no esté repetido
				List<Usuario> match = UsuarioHome.findByExample(sample);
				if (!match.isEmpty()){
					validos = false;
					FieldValueError.setFieldError(PARAM_USERNAME,
							"El nombre de acceso ya está en uso, por favor seleccione uno que no esté en uso.",
							request);
				}
			}
			if (validos) {
				usuario.setNombreReal(nombreReal);
				usuario.setApellido(apellido);
				usuario.setNombreAcceso(nombreAcceso);
				usuario.setClaveAcceso(claveAcceso);

				UsuarioHome.modificaUsuario(usuario);
				UserNotification
						.addMessage(
								request,
								"El Perfil de Usuario ha sido modificado satisfactoriamente ..!",
								Level.INFO);
			} else {
				UserNotification.addMessage(request,
						"Ha ocurrido un error, por favor verifique los datos!",
						Level.ERROR);
			}
			setListaUsuarios(request);

		} catch (HibernateException e) {
			UserNotification
					.addMessage(
							request,
							"Ha ocurrido un error al acceder a la base de datos. Por favor comuníquelo al administrador del sitio.",
							Level.ERROR);
		}
		request.getRequestDispatcher("do_modifica_usuario.jsp").forward(
				request, response);
	}

	/**
	 * @param nombreReal
	 * @param apellido
	 * @param nombreAcceso
	 * @param claveAcceso
	 * @param request
	 * @return
	 */
	private boolean paramsValidos(String nombreReal, String apellido, String nombreAcceso, String claveAcceso, HttpServletRequest request) {
		boolean ok = true;

		if (nombreReal == null ||
				nombreReal.trim().equals("")){
			ok = false;
			FieldValueError.setFieldError(PARAM_NOMBRE_REAL,
					"Este campo no puede ser vacío.", request);
		}
		if (apellido == null ||
				apellido.trim().equals("")){
			ok = false;
			FieldValueError.setFieldError(PARAM_APELLIDO,
					"Este campo no puede ser vacío.", request);
		}
		if (nombreAcceso == null ||
				nombreAcceso.trim().equals("")){
			ok = false;
			FieldValueError.setFieldError(PARAM_USERNAME,
					"Este campo no puede ser vacío.", request);
		}
		if (claveAcceso == null ||
				claveAcceso.trim().equals("")){
			ok = false;
			FieldValueError.setFieldError(PARAM_PASSWORD,
					"Este campo no puede ser vacío.", request);
		}
		return ok;
	}

	/**
	 * Responsable de preparar los datos necesarios para la página de edición.
	 * 
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	private void doListar(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		try {
			setListaUsuarios(request);
		} catch (HibernateException e) {
			UserNotification
			.addMessage(
					request,
					"Ha ocurrido un error al acceder a la base de datos. Por favor comuníquelo al administrador del sitio.",
					Level.ERROR);
		}

		Usuario usuario = LoginServlet.getUsuarioEnSesion(request);
		FieldValueError.setFieldValue(PARAM_NOMBRE_REAL, usuario.getNombreReal(), request);
		FieldValueError.setFieldValue(PARAM_APELLIDO, usuario.getApellido(), request);
		FieldValueError.setFieldValue(PARAM_USERNAME, usuario.getNombreAcceso(), request);
		FieldValueError.setFieldValue(PARAM_PASSWORD, usuario.getClaveAcceso(), request);

		request.getRequestDispatcher("do_modifica_usuario.jsp").forward(
				request, response);
	}

	/**
	 * Método auxiliar para agregar al request la lista de usuarios.
	 * 
	 * @param request
	 */
	private void setListaUsuarios(HttpServletRequest request) {
		String consultaHQL = "select u from Usuario as u";
		List<Usuario> listaDeUsuarios = UsuarioHome
				.consultaUsuarios(consultaHQL);

		request.setAttribute(LISTA_USUARIOS, listaDeUsuarios);
	}

 } 