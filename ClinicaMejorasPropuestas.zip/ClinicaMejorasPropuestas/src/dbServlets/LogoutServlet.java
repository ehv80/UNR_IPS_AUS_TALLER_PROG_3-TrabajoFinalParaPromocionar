package dbServlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;

/**
 * Servlet implementation class for Servlet: LogoutServlet
 *
 */
 public class LogoutServlet extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet 
 {
	 private static String mensaje;
	 
	 public static void setMensaje(String mensaje) { LogoutServlet.mensaje = mensaje; }
	 
	 public static String getMensaje() { return LogoutServlet.mensaje; }
	 
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public LogoutServlet() {
		super();
	}   	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String eleccionLogout;
		if( request.getParameter("eleccionLogout") != null && !request.getParameter("eleccionLogout").equals("") )
		{
			eleccionLogout = request.getParameter("eleccionLogout");
			if( eleccionLogout != null && eleccionLogout.equals("SI") )
			{
				/*  Por último invalida la session de HttpSession y redirecciona.   */
				request.getSession().setAttribute("mensajeBienvenida", null);
				request.getSession().setAttribute("usuario", null);
				request.getSession().invalidate();
			  	response.sendRedirect("index.jsp");
			}
			if(eleccionLogout != null && eleccionLogout.equals("NO") )
			{
				LogoutServlet.setMensaje("Usted ha elegido continuar usando el Portal ...");
				request.getSession().setAttribute("mensaje", LogoutServlet.getMensaje() );
				response.sendRedirect("logout.jsp");
			}
			if( eleccionLogout != null && eleccionLogout.equals("") )
			{
				LogoutServlet.setMensaje("Debe elegir por \"SI\" o por \"NO\" ..! ");
				request.getSession().setAttribute("mensaje", LogoutServlet.getMensaje() );
				response.sendRedirect("logout.jsp");
			}
			if( eleccionLogout == null )
			{
				LogoutServlet.setMensaje("Debe elegir por \"SI\" o por \"NO\" ..! ");
				request.getSession().setAttribute("mensaje", LogoutServlet.getMensaje() );
				response.sendRedirect("logout.jsp");
			}
		}
		else
		{
			LogoutServlet.setMensaje("Debe elegir por \"SI\" o por \"NO\" ..! ");
			request.getSession().setAttribute("mensaje", LogoutServlet.getMensaje() );
			response.sendRedirect("logout.jsp");
		}
	}   	  	    
}