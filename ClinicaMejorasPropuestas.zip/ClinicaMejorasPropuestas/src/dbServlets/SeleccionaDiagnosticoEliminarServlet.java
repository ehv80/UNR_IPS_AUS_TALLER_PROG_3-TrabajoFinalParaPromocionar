package dbServlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;

import clinica.Diagnostico;
import clinica.DiagnosticoHome;

/**
 * Servlet implementation class for Servlet: SeleccionaDiagnosticoEliminarServlet
 *
 */
 public class SeleccionaDiagnosticoEliminarServlet extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet 
 {
	 private static String mensaje;
	 
	 public static void setMensaje(String mensaje){ SeleccionaDiagnosticoEliminarServlet.mensaje = mensaje; }
	 
	 public static String getMensaje(){	return SeleccionaDiagnosticoEliminarServlet.mensaje; }
	 
    /* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public SeleccionaDiagnosticoEliminarServlet() 
	{
		super();
	}   	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}  	
	
	/* (non-Java-doc)
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String selectorDiagnosticoEliminar;
		Diagnostico diagnosticoEliminar;
		String consultaHQL;
		List<Diagnostico> listaDeDiagnosticos;
		
		try
		{
			if( request.getParameter("selectorDiagnosticoEliminar") != null && !request.getParameter("selectorDiagnosticoEliminar").equals(""))
			{
				selectorDiagnosticoEliminar = request.getParameter("selectorDiagnosticoEliminar");
				
				//lo pongo en la HttpSession para tenerlo
				request.getSession().setAttribute("idDiagnosticoEliminar", selectorDiagnosticoEliminar);
				
				consultaHQL = "select d from Diagnostico as d where 1=1 and d.idDiagnostico = '" + selectorDiagnosticoEliminar + "'";
				//1º Obtiene el Diagnóstico desde la Base de Datos
				listaDeDiagnosticos = DiagnosticoHome.consultaDiagnosticos(consultaHQL);
				if(listaDeDiagnosticos == null)
				{
					if( DiagnosticoHome.getMensaje() != null && !DiagnosticoHome.getMensaje().equals("") )
					{
						SeleccionaDiagnosticoEliminarServlet.setMensaje( DiagnosticoHome.getMensaje() );
						request.getSession().setAttribute("mensajeSeleccionaDiagnosticoEliminar", 
								SeleccionaDiagnosticoEliminarServlet.getMensaje() );
						response.sendRedirect("do_elimina_diagnostico.jsp");
					}
					else
					{
						SeleccionaDiagnosticoEliminarServlet.setMensaje("Error en DiagnosticoHome.consultaDiagnosticos(consulatHQL) ..!");
						request.getSession().setAttribute("mensajeSeleccionaDiagnosticoEliminar", 
								SeleccionaDiagnosticoEliminarServlet.getMensaje() );
						response.sendRedirect("do_elimina_diagnostico.jsp");
					}
				}
				else if( listaDeDiagnosticos != null )
				{
					if( listaDeDiagnosticos.isEmpty() )
					{
						SeleccionaDiagnosticoEliminarServlet.setMensaje("El Diagnóstico seleccionado ya no está almacenado en la Base de Datos ..!");
						request.getSession().setAttribute("mensajeSeleccionaDiagnosticoEliminar", 
								SeleccionaDiagnosticoEliminarServlet.getMensaje() );
						response.sendRedirect("do_elimina_diagnostico.jsp");
					}
					else if( !listaDeDiagnosticos.isEmpty() )
					{
						if( listaDeDiagnosticos.size() == 1 )
						{
							if( String.valueOf( listaDeDiagnosticos.get(0).getIdDiagnostico() ).equals(selectorDiagnosticoEliminar) )
							{
								diagnosticoEliminar = listaDeDiagnosticos.get(0); //índice comienza en cero!

								request.getSession().setAttribute("diagnosticoEliminar", diagnosticoEliminar);

								//todavía no pone en null el Paciente seleccionado
								response.sendRedirect("do_elimina_diagnostico.jsp");
							}
						}
						else
						{
							SeleccionaDiagnosticoEliminarServlet.setMensaje("Error en la consulta HQL al buscar Diagnóstico ..!");
							request.getSession().setAttribute("mensajeSeleccionaDiagnosticoEliminar", 
									SeleccionaDiagnosticoEliminarServlet.getMensaje() );
							response.sendRedirect("do_elimina_diagnostico.jsp");
						}
					}
				}
			}
			else
			{
				SeleccionaDiagnosticoEliminarServlet.setMensaje("Debe elegir un Diagnóstico en el selector ..!");
				request.getSession().setAttribute("mensajeSeleccionaDiagnosticoEliminar", SeleccionaDiagnosticoEliminarServlet.getMensaje() );
				response.sendRedirect("do_elimina_diagnostico.jsp");
			}
		}
		catch(HibernateException hex)
		{
			SeleccionaDiagnosticoEliminarServlet.setMensaje(
					"Ha ocurrido una Excepción en SeleccionaDiagnosticoEliminarServlet.doPost( request, response ) " + hex);
			request.getSession().setAttribute("mensajeSeleccionaDiagnosticoEliminar", SeleccionaDiagnosticoEliminarServlet.getMensaje() );
			response.sendRedirect("do_elimina_diagnostico.jsp");
		}
		catch(Exception ex)
		{
			SeleccionaDiagnosticoEliminarServlet.setMensaje(
					"Ha ocurrido una Excepción en SeleccionaDiagnosticoEliminarServlet.doPost( request, response ) " + ex);
			request.getSession().setAttribute("mensajeSeleccionaDiagnosticoEliminar", SeleccionaDiagnosticoEliminarServlet.getMensaje() );
			response.sendRedirect("do_elimina_diagnostico.jsp");
		}
	}   	  	    
}