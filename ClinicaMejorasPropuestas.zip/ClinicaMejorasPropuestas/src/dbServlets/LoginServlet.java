package dbServlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.HibernateException;

import utility.UserNotification;
import utility.UserNotification.Level;

import clinica.Usuario;
import clinica.UsuarioHome;
import clinica.ValidationException;

/**
 * Servlet implementation class for Servlet: LoginServlet
 * 
 */
public class LoginServlet extends javax.servlet.http.HttpServlet implements
		javax.servlet.Servlet {
	private static int contadorIntentosDeAcceso = 0;

	private static final String USUARIO = "usuario";

	/*
	 * (non-Java-doc)
	 * 
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */
	public LoginServlet() {
		super();
	}

	/*
	 * (non-Java-doc)
	 * 
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request,
	 *      HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/*
	 * (non-Java-doc)
	 * 
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request,
	 *      HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String username;
		String password;
		List<Usuario> listaDeUsuarios;
		Usuario usuario;
		try {
			username = request.getParameter("username");
			password = request.getParameter("password");
			usuario = new Usuario(null, null, username, null);
			listaDeUsuarios = UsuarioHome.findByExample(usuario);
			if (listaDeUsuarios.isEmpty()
					|| !listaDeUsuarios.get(0).getClaveAcceso()
							.equals(password))
				throw new ValidationException(
						"Usuario y password desconocidos, por favor vuelva a intentar!.");
			usuario = listaDeUsuarios.get(0);
			request.getSession().setAttribute(LoginServlet.USUARIO, usuario);
			UserNotification.addMessage(request, "Bienvenido al Portal "
					+ usuario.getNombreReal() + " " + usuario.getApellido(),
					Level.INFO);
		} catch (HibernateException hex) {
			UserNotification
					.addMessage(
							request,
							"Ha ocurrido un error al acceder a la base de datos. Por favor comuníquelo al administrador del sitio.",
							Level.ERROR);
			request.getRequestDispatcher("login.jsp")
					.forward(request, response);
			return;
		} catch (ValidationException ex) {
			UserNotification.addMessage(request, ex.getMessage(), Level.ERROR);
			request.getRequestDispatcher("login.jsp")
					.forward(request, response);
			return;
		}
		request.getRequestDispatcher("index.jsp").forward(request, response);
	}
	
	public static Usuario getUsuarioEnSesion(HttpServletRequest request){
		return (Usuario)request.getSession().getAttribute(USUARIO);
	}
}