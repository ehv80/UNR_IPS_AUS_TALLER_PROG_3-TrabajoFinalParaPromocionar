/**
 * 
 */
package utility;

import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * @author ehv80
 *
 */
public class FechaUtil {
	
	private static String mensaje;
	
	
	private static ArrayList<String> listaDeAnios;
	private static ArrayList<String> listaDeMeses;
	private static ArrayList<String> listaDeDias;
	
	public static void setMensaje( String mensaje ){ FechaUtil.mensaje = mensaje; }
	
	public static String getMensaje(){ return FechaUtil.mensaje; }
	
	
	public static Iterator<String> getIteradorListaDeAnios()
	{
		listaDeAnios = new  ArrayList<String>();
		for( int i = 1900 ; i <= 2099 ; i++ )
		{
			String anioTemp = String.valueOf( i );
			listaDeAnios.add(anioTemp);
		}
		Iterator<String> iteradorListaDeAnios = (Iterator<String>)listaDeAnios.iterator();
		return iteradorListaDeAnios;
	}
	
	public static Iterator<String> getIteradorListaDeMeses()
	{
		listaDeMeses = new ArrayList<String>();
		for( int i = 1 ; i <= 12 ; i++ )
		{
			if( i <= 9 )
			{
				String mesTemp = "0" + String.valueOf(i);
				listaDeMeses.add(mesTemp);
			}
			if( i > 9 )
			{
				String mesTemp = String.valueOf(i);
				listaDeMeses.add(mesTemp);
			}
		}
		Iterator<String> iteradorListaDeMeses = (Iterator<String>) listaDeMeses.iterator();
		return iteradorListaDeMeses;
	}
	
	public static Iterator<String> getIteradorListaDeDias()
	{
		listaDeDias = new ArrayList<String>();
		for( int i = 1 ; i <= 31 ; i++ )
		{
			if( i <= 9 )
			{
				String diaTemp = "0" + String.valueOf(i);
				listaDeDias.add(diaTemp);
			}
			if( i > 9 )
			{
				String diaTemp = String.valueOf(i);
				listaDeDias.add(diaTemp);
			}
		}
		Iterator<String> iteradorListaDeDias = (Iterator<String>) listaDeDias.iterator();
		return iteradorListaDeDias;
	}
	
	public static Date validaFecha( String cadenaFecha )
	{
		String mascaraFecha = "yyyy-MM-dd"; //[año]-[mes del año]-[día del mes]
		Date fecha;
		SimpleDateFormat formateadorFechaSimple;
		try
		{
			formateadorFechaSimple = new SimpleDateFormat( mascaraFecha );
			formateadorFechaSimple.setLenient(false);//no sea indulgente, sino mas bién riguroso
			fecha = formateadorFechaSimple.parse(cadenaFecha);
			if( fecha != null )
			{
				return fecha;
			}
			else
			{
				FechaUtil.setMensaje("Debe seleccionar una Fecha que sea válida ..!");
				return null;
			}
		}
		catch( ParseException pex )
		{
			FechaUtil.setMensaje(" Debe seleccionar una Fecha que sea válida ..!      Detalles :" + pex);
			return null;			
		}
		catch( IllegalArgumentException iaex)
		{
			FechaUtil.setMensaje(" Debe seleccionar una Fecha que sea válida ..!      Detalles: " + iaex);
			return null;
		}
	}
	
}
