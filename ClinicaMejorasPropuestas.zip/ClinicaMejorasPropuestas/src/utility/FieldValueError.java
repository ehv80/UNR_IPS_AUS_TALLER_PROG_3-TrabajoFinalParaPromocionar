package utility;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

/**
 * Helper utility class to manage form fields values and error messages.
 * 
 * @author patricio.keilty@gmail.com
 *
 */
public class FieldValueError {

	private static final String PARAMS_ERRORS = "form_errors";
	private static final String PARAMS_VALUES = "form_values";
	
	/**
	 * @param request
	 * @return
	 */
	private static Map<String, String> getParamsMap(HttpServletRequest request) {
		Map<String, String> mapa = (Map<String, String>)request.getAttribute(FieldValueError.PARAMS_VALUES);
		if (mapa == null){
			mapa = new HashMap<String, String>();
			request.setAttribute(FieldValueError.PARAMS_VALUES, mapa);
		}
		return mapa;
	}

	private static Map<String, String> getErrorsMap(HttpServletRequest request) {
		Map<String, String> mapa = (Map<String, String>)request.getAttribute(FieldValueError.PARAMS_ERRORS);
		if (mapa == null){
			mapa = new HashMap<String, String>();
			request.setAttribute(FieldValueError.PARAMS_ERRORS, mapa);
		}
		return mapa;
	}

	/**
	 * Método auxiliar para obtener el valor de un campo por nombre.
	 * Intenta obtenerlo del atributo, sino del param equivalente, y sino lo encuentra retorna vacío.  
	 */
	public static String getFieldValue(String fieldName, HttpServletRequest request){
		Map<String, String> mapa = (Map<String, String>)request.getAttribute(FieldValueError.PARAMS_VALUES);
		String value = "";
		String found = null;
		if (mapa != null){
			found = mapa.get(fieldName);
			if (found != null)
				value = found;
		} else {
			found = request.getParameter(fieldName);
			if (found != null)
				value = found;
		}
		return value;
	}

	public static void setFieldValue(String fieldName, String fieldValue, HttpServletRequest request){
		Map<String, String> mapa = getParamsMap(request);
		mapa.put(fieldName, fieldValue);
	}

	/**
	 * Método auxiliar para obtener la descripción del error en un campo por nombre.
	 */
	// TODO support more than one error in a field
	public static String getFieldError(String fieldName, HttpServletRequest request){
		Map<String, String> mapa = (Map<String, String>)request.getAttribute(FieldValueError.PARAMS_ERRORS);
		String value = "";
		if (mapa != null){
			String valor = mapa.get(fieldName);
			if (valor != null)
				value = valor;
		}
		return value;
	}

	public static void setFieldError(String fieldName, String fieldError, HttpServletRequest request){
		Map<String, String> mapa = getErrorsMap(request);
		mapa.put(fieldName, fieldError);
	}
}
